﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Timers;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    public struct Group
    {
        public Group(string e, string t, string r)
        {
            english = e; transcript = t;
            russian = r;
        }
        public string english, transcript;
        public string russian;
    };

    public enum Direction
    {
        En2Ru,
        Ru2En
    };

    public enum Selection
    {
        Linear,
        Random
    };

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow: Window
    {
        private Random rndGen = new Random();
        private Timer mainTimer = new Timer();

        private Direction trdir = Direction.En2Ru;
        private int counter0;
        private int counter1;
        private int correctIdx;
        private int[] idxArray = new int[5];
        private TextBox[] tbxArray = new TextBox[5];
        private CheckBox[] cbxArray = new CheckBox[9];
        private List<Group>[] wrdArray = new List<Group>[9];

        private int currWrdIdx = 0;
        private int prevWrdIdx = 0;
        private int wordsNumber = 0;
        private bool needRetry = false;
        private Selection selmode = Selection.Linear;

        public MainWindow()
        {
            mainTimer.Stop();
            mainTimer.Interval = 1000;
            mainTimer.AutoReset = false;
            mainTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent0);

            var reader = new StreamReader(File.OpenRead(@"..\Data\Operations.csv"));
            wrdArray[0] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[0].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[0].Count;

            reader = new StreamReader(File.OpenRead(@"..\Data\ThingsGeneral.csv"));
            wrdArray[1] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[1].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[1].Count;

            reader = new StreamReader(File.OpenRead(@"..\Data\ThingsPictured.csv"));
            wrdArray[2] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[2].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[2].Count;

            reader = new StreamReader(File.OpenRead(@"..\Data\QualitiesGeneral.csv"));
            wrdArray[3] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[3].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[3].Count;

            reader = new StreamReader(File.OpenRead(@"..\Data\QualitiesOpposite.csv"));
            wrdArray[4] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[4].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[4].Count;

            reader = new StreamReader(File.OpenRead(@"..\Data\Numbers.csv"));
            wrdArray[5] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[5].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[5].Count;

            reader = new StreamReader(File.OpenRead(@"..\Data\Actions.csv"));
            wrdArray[6] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[6].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[6].Count;

            reader = new StreamReader(File.OpenRead(@"..\Data\EnCourses0.csv"));
            wrdArray[7] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[7].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[7].Count;

            reader = new StreamReader(File.OpenRead(@"..\Data\EnCourses1.csv"));
            wrdArray[8] = new List<Group>();
            while(!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(';');
                wrdArray[8].Add(new Group(values[0], values[1], values[2]));
            }
            reader.Close(); wordsNumber += wrdArray[8].Count;

            InitializeComponent();
            {
                cbxArray[0] = checkBox0;
                cbxArray[1] = checkBox1;
                cbxArray[2] = checkBox2;
                cbxArray[3] = checkBox3;
                cbxArray[4] = checkBox4;
                cbxArray[5] = checkBox5;
                cbxArray[6] = checkBox6;
                cbxArray[7] = checkBox7;
                cbxArray[8] = checkBox8;

                tbxArray[0] = textBox1;
                tbxArray[1] = textBox2;
                tbxArray[2] = textBox3;
                tbxArray[3] = textBox4;
                tbxArray[4] = textBox5;

                prevWrdIdx = wordsNumber - 2;
                currWrdIdx = wordsNumber - 1;

                counter0 = 0;
                counter1 = 0;
                textBox6.Text = counter0.ToString();
                textBox7.Text = counter1.ToString();
                textBox6.Background = new SolidColorBrush(Color.FromScRgb(1.0f, 0.86274f, 1.0f, 0.86274f));
                textBox7.Background = new SolidColorBrush(Color.FromScRgb(1.0f, 1.0f, 0.86274f, 0.86274f));
            }
        }

        private string GetSourceWord(int setidx, int wrdidx, out string transcript)
        {
            string translation = "";
            transcript = "---";
            switch (trdir)
            {
                case Direction.En2Ru:
                {
                    translation = wrdArray[setidx][wrdidx].english;
                    transcript = wrdArray[setidx][wrdidx].transcript;
                    break;
                }
                case Direction.Ru2En:
                {
                    translation = wrdArray[setidx][wrdidx].russian;
                    break;
                }
            }
            return(translation);
        }

        private string GetTargetWord(int setidx, int wrdidx, out string transcript)
        {
            string translation = "";
            transcript = "---";
            switch (trdir)
            {
                case Direction.En2Ru:
                {
                    translation = wrdArray[setidx][wrdidx].russian;
                    break;
                }
                case Direction.Ru2En:
                {
                    translation = wrdArray[setidx][wrdidx].english;
                    transcript = wrdArray[setidx][wrdidx].transcript;
                    break;
                }
            }
            return(translation);
        }

        private void OnTimedEvent0(object source, ElapsedEventArgs e)
        {
            // show source word
            Dispatcher.BeginInvoke(new Action(() =>
            {
                markFieldsDefault();

                int setidx = 0;
                int wrdidx = 0;
                GetMainWordIndices(out setidx, out wrdidx);

                idxArray[0] = setidx ^ wrdidx;
                correctIdx = rndGen.Next(tbxArray.Length);

                string transcript = "";
                textBox0.Text = GetSourceWord(setidx, wrdidx, out transcript);
                textBox8.Text = transcript;

                tbxArray[correctIdx].Text = GetTargetWord(setidx, wrdidx, out transcript);

                int cI = 0;
                while(cI < tbxArray.Length)
                {
                    if(cI != correctIdx)
                    {
                        GetAuxWordIndices(out setidx, out wrdidx);

                        bool needNewIteration = false;
                        for(int cJ = 0; cJ < idxArray.Length; cJ++)
                        {
                            needNewIteration |= (idxArray[cJ] == (setidx ^ wrdidx));
                        }
                        if(needNewIteration)
                        {
                            continue;
                        }
                        tbxArray[cI].Text = GetTargetWord(setidx, wrdidx, out transcript);
                    }
                    cI++;
                }
            }));
        }

        private void ButtonStart_Click(object sender, RoutedEventArgs e)
        {
            if((string)buttonStart.Content == "Stop")
            {
                mainTimer.Stop();

                buttonStart.Content = "Start";
                radioButton0.IsEnabled = true;
                radioButton1.IsEnabled = true;
            }
            else
            {
                ClearAll();
                buttonStart.Content = "Stop";
                radioButton0.IsEnabled = false;
                radioButton1.IsEnabled = false;

                mainTimer.Start();
            }
        }
        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            mainTimer.Stop();
            ClearAll();
            mainTimer.Start();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if(correctIdx == 0)
            {
                counter0++; textBox6.Text = counter0.ToString();
            }
            else
            {
                counter1++; textBox7.Text = counter1.ToString();
            }
            markFieldsCorrect();
            mainTimer.Start();
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if(correctIdx == 1)
            {
                counter0++; textBox6.Text = counter0.ToString();
            }
            else
            {
                counter1++; textBox7.Text = counter1.ToString();
            }
            markFieldsCorrect();
            mainTimer.Start();
        }
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if(correctIdx == 2)
            {
                counter0++; textBox6.Text = counter0.ToString();
            }
            else
            {
                counter1++; textBox7.Text = counter1.ToString();
            }
            markFieldsCorrect();
            mainTimer.Start();
        }
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if(correctIdx == 3)
            {
                counter0++; textBox6.Text = counter0.ToString();
            }
            else
            {
                counter1++; textBox7.Text = counter1.ToString();
            }
            markFieldsCorrect();
            mainTimer.Start();
        }
        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            if(correctIdx == 4)
            {
                counter0++; textBox6.Text = counter0.ToString();
            }
            else
            {
                counter1++; textBox7.Text = counter1.ToString();
            }
            markFieldsCorrect();
            mainTimer.Start();
        }

        private void buttonRetry_Click(object sender, RoutedEventArgs e)
        {
            mainTimer.Stop();
            {
                needRetry = true;
            }
            mainTimer.Start();
        }

        private void CheckBox0_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }
        private void CheckBox1_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }
        private void CheckBox2_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }
        private void CheckBox3_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }
        private void CheckBox4_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }
        private void CheckBox5_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }
        private void CheckBox6_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }
        private void CheckBox7_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }
        private void CheckBox8_Checked(object sender, RoutedEventArgs e)
        {
            CheckAndEnable();
        }

        private void CheckBox0_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }
        private void CheckBox1_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }
        private void CheckBox2_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }
        private void CheckBox3_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }
        private void CheckBox4_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }
        private void CheckBox5_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }
        private void CheckBox6_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }
        private void CheckBox7_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }
        private void CheckBox8_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckAndDisable();
        }

        private void radioButton0_Checked(object sender, RoutedEventArgs e)
        {
            trdir = Direction.En2Ru; ;
        }
        private void radioButton1_Checked(object sender, RoutedEventArgs e)
        {
            trdir = Direction.Ru2En;
        }

        private void radioButton2_Checked(object sender, RoutedEventArgs e)
        {
            selmode = Selection.Linear;
        }
        private void radioButton3_Checked(object sender, RoutedEventArgs e)
        {
            selmode = Selection.Random;
        }

        private void ClearAll()
        {
            prevWrdIdx = wordsNumber - 2;
            currWrdIdx = wordsNumber - 1;

            counter0 = 0;
            counter1 = 0;
            textBox6.Text = counter0.ToString();
            textBox7.Text = counter1.ToString();

            textBox0.Text = "---";
            textBox8.Text = "---";

            textBox1.Text = "---";
            textBox2.Text = "---";
            textBox3.Text = "---";
            textBox4.Text = "---";
            textBox5.Text = "---";
        }

        private void GetAuxWordIndices(out int setidx, out int wrdidx)
        {
            bool foundCorrectIdx = false;
            do
            {
                setidx = rndGen.Next(cbxArray.Length);

                for(int cI = 0; cI < cbxArray.Length; cI++)
                {
                    if((cbxArray[cI].IsChecked ?? false) && setidx == cI)
                    {
                        foundCorrectIdx = true;
                        break;
                    }
                }
            }
            while(!foundCorrectIdx);

            wrdidx = rndGen.Next(wrdArray[setidx].Count);
        }

        private void GetMainWordIndices(out int setidx, out int wrdidx)
        {
            int setIdx = 0;
            int wrdIdx = 0;
            bool foundCorrectIdx = false;

            if(needRetry)
            {
                currWrdIdx = prevWrdIdx;

                int wordsAmount = 0;
                for (int cI = 0; cI < cbxArray.Length; cI++)
                {
                    wordsAmount += wrdArray[cI].Count;
                    if (wordsAmount > currWrdIdx)
                    {
                        if (cbxArray[cI].IsChecked ?? false)
                        {
                            setIdx = cI;
                            wrdIdx = currWrdIdx - (wordsAmount - wrdArray[cI].Count);

                            foundCorrectIdx = true;
                            break;
                        }
                        else
                        {
                            currWrdIdx = wordsAmount;
                        }
                    }
                }
                needRetry = false; goto ret;
            }
            prevWrdIdx = currWrdIdx;

            if (selmode == Selection.Random)
            {
                do
                {
                    currWrdIdx = rndGen.Next(wordsNumber);

                    int wordsAmount = 0;
                    for(int cI = 0; cI < cbxArray.Length; cI++)
                    {
                        wordsAmount += wrdArray[cI].Count;
                        if(wordsAmount > currWrdIdx && (cbxArray[cI].IsChecked ?? false))
                        {
                            setIdx = cI;
                            wrdIdx = currWrdIdx - (wordsAmount - wrdArray[cI].Count);

                            if(wrdIdx >= 0)
                            {
                                foundCorrectIdx = true;
                                break;
                            }
                        }
                    }
                }
                while(!foundCorrectIdx);
            }
            else
            {
                do
                {
                    currWrdIdx = (currWrdIdx + 1) % wordsNumber;

                    int wordsAmount = 0;
                    for(int cI = 0; cI < cbxArray.Length; cI++)
                    {
                        wordsAmount += wrdArray[cI].Count;
                        if(wordsAmount > currWrdIdx)
                        {
                            if(cbxArray[cI].IsChecked ?? false)
                            {
                                setIdx = cI;
                                wrdIdx = currWrdIdx - (wordsAmount - wrdArray[cI].Count);

                                foundCorrectIdx = true;
                                break;
                            }
                            else
                            {
                                currWrdIdx = wordsAmount;
                            }
                        }
                    }
                }
                while(!foundCorrectIdx);
            }

            ret:
            setidx = setIdx;
            wrdidx = wrdIdx;
        }

        private void markFieldsCorrect()
        {
            for(int cI = 0; cI < tbxArray.Length; cI++)
            {
                if(correctIdx == cI)
                {
                    tbxArray[cI].Background = new SolidColorBrush(Color.FromScRgb(1.0f, 0.86274f, 1.0f, 0.86274f));
                    continue;
                }
                tbxArray[cI].Background = new SolidColorBrush(Color.FromScRgb(1.0f, 1.0f, 0.86274f, 0.86274f));
            }
        }
        private void markFieldsDefault()
        {
            for(int cI = 0; cI < tbxArray.Length; cI++)
            {
                idxArray[cI] = 0;
                tbxArray[cI].Background = new SolidColorBrush(Colors.White);
            }
        }

        private void CheckAndEnable()
        {
            int amount = 0;
            for(int cI = 0; cI < cbxArray.Length; cI++)
            {
                if(cbxArray[cI] != null && !cbxArray[cI].IsEnabled)
                {
                    amount++;
                }
            }
            if(amount > 0)
            {
                for(int cI = 0; cI < cbxArray.Length; cI++)
                {
                    if(cbxArray[cI] != null && !cbxArray[cI].IsEnabled)
                    {
                        cbxArray[cI].IsEnabled = true;
                    }
                }
            }
        }

        private void CheckAndDisable()
        {
            int amount = 0;
            for(int cI = 0; cI < cbxArray.Length; cI++)
            {
                if(cbxArray[cI] != null && cbxArray[cI].IsChecked.Value)
                {
                    amount++;
                }
            }
            if(amount == 1)
            {
                for(int cI = 0; cI < cbxArray.Length; cI++)
                {
                    if(cbxArray[cI] != null && cbxArray[cI].IsChecked.Value)
                    {
                        cbxArray[cI].IsEnabled = false;
                    }
                }
            }
        }
    }
}

/*
            if (selmode == Selection.Random)
            {
                bool foundCorrectIdx = false;
                do
                {
                    prevsetidx = currsetidx;
                    currsetidx = rndGen.Next(cbxArray.Length);

                    for(int cI = 0; cI < cbxArray.Length; cI++)
                    {
                        if((cbxArray[cI].IsChecked ?? false) && currsetidx == cI)
                        {
                            foundCorrectIdx = true;
                            break;
                        }
                    }
                }
                while(!foundCorrectIdx);

                prevwrdidx = currwrdidx;
                currwrdidx = rndGen.Next(wrdArray[currsetidx].Count);

                setidx = currsetidx;
                wrdidx = currwrdidx;
            }
            else
            {
                prevsetidx = currsetidx;
                for(int cI = 0; cI < cbxArray.Length; cI++)
                {
                    if(cbxArray[currsetidx].IsChecked ?? false)
                    {
                        if(prevsetidx != currsetidx)
                        {
                            prevsetidx = currsetidx;
                            prevwrdidx = currwrdidx = - 1;
                        }
                        break;
                    }
                    else
                    {
                        currsetidx = (currsetidx + 1) % cbxArray.Length;
                    }
                }

                if(currwrdidx < wrdArray[currsetidx].Count - 1)
                {
                    prevwrdidx = currwrdidx;
                    currwrdidx++;
                }
                else
                {
                    for(int cI = 0; cI < cbxArray.Length; cI++)
                    {
                        currsetidx = (currsetidx + 1) % cbxArray.Length;
                        if(cbxArray[currsetidx].IsChecked ?? false)
                        {
                            break;
                        }
                    }
                    currwrdidx = 0;
                }
                setidx = currsetidx;
                wrdidx = currwrdidx;
            }
*/
