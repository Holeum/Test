﻿// SphereRefraction.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#define _USE_MATH_DEFINES
#define NOMINMAX

#include <math.h>
#include <float.h>
#include <stdio.h>
#include <stdlib.h>

#include <graphics.h>


typedef float real;
//typedef double real;

const int ITERS_MAX = 16;
const int STEPS_MAX = 64;
const real SAFE_OFFSET = 0.0001f;
const real TOLERANCE = 1.0e-04f;
const real MIN_VALUE = FLT_EPSILON;

struct float2;
struct float3;
struct float4;
struct float2x2;
struct float3x3;
float3 spherical2cartesian(real r, real theta, real phi);
float3 spherical2cartesian(const float3& s);
float3 cartesian2spherical(const float3& v);

struct float2 {
	real x;
	real y;
	float2() : x(0.0f), y(0.0f) {}
	float2(const float2& v) : x(v.x), y(v.y) {}
	float2(const real x, const real y) : x(x), y(y) {}
	float2& operator=(const float2& v) {
		if (&v != this) {
			this->x = v.x; this->y = v.y;
		}
		return(*this);
	}
};

struct float3 {
	real x;
	real y;
	real z;
	float3() : x(0.0f), y(0.0f), z(0.0f) {}
	float3(const float3& v) : x(v.x), y(v.y), z(v.z) {}
	float3(const real x, const real y, const real z) : x(x), y(y), z(z) {}
	float3& operator=(const float3& v) {
		if (&v != this) {
			this->x = v.x; this->y = v.y; this->z = v.z;
		}
		return(*this);
	}
};

struct float4 {
	real x;
	real y;
	real z;
	real w;
	float4() : x(0.0f), y(0.0f), z(0.0f), w(0.0f) {}
	float4(const float4& v) : x(v.x), y(v.y), z(v.z), w(v.w) {}
	float4(const real x, const real y, const real z, const real w) : x(x), y(y), z(z), w(w) {}
	float4& operator=(const float4& v) {
		if (&v != this) {
			this->x = v.x; this->y = v.y; this->z = v.z; this->w = v.w;
		}
		return(*this);
	}
};

struct float2x2 {
	real m00;
	real m01;
	real m10;
	real m11;
	float2x2() : m00(1.0f), m01(0.0f), m10(0.0f), m11(1.0f) {}
	float2x2(const float2x2& m) : m00(m.m00), m01(m.m01), m10(m.m10), m11(m.m11) {}
	float2x2(const real m00, const real m01, const real m10, const real m11) : m00(m00), m01(m01), m10(m10), m11(m11) {}
	float2x2& operator=(const float2x2& m) {
		if (&m != this) {
			this->m00 = m.m00; this->m01 = m.m01;
			this->m10 = m.m10; this->m11 = m.m11;
		}
		return(*this);
	}
};

struct float3x3 {
	real m00;
	real m01;
	real m02;
	real m10;
	real m11;
	real m12;
	real m20;
	real m21;
	real m22;
	float3x3() : m00(1.0f), m01(0.0f), m02(0.0f),
		m10(0.0f), m11(1.0f), m12(0.0f),
		m20(0.0f), m21(0.0f), m22(1.0f)
	{}

	float3x3(const float3x3& m) : m00(m.m00), m01(m.m01), m02(m.m02),
		m10(m.m10), m11(m.m11), m12(m.m12),
		m20(m.m20), m21(m.m21), m22(m.m22)
	{}

	float3x3(const real m00, const real m01, const real m02,
		const real m10, const real m11, const real m12,
		const real m20, const real m21, const real m22) : m00(m00), m01(m01), m02(m02),
		m10(m10), m11(m11), m12(m12),
		m20(m20), m21(m21), m22(m22)
	{}

	float3x3& operator=(const float3x3& m) {
		if (&m != this) {
			this->m00 = m.m00; this->m01 = m.m01; this->m02 = m.m02;
			this->m10 = m.m10; this->m11 = m.m11; this->m12 = m.m12;
			this->m20 = m.m20; this->m21 = m.m21; this->m22 = m.m22;
		}
		return(*this);
	}
};

float3 add(const float3& a, const float3& b) {
	float3 c;
	c.x = a.x + b.x;
	c.y = a.y + b.y;
	c.z = a.z + b.z;
	return(c);
}
float3 add(const float3& a, const real b) {
	float3 c;
	c.x = a.x + b;
	c.y = a.y + b;
	c.z = a.z + b;
	return(c);
}
float3 sub(const float3& a, const float3& b) {
	float3 c;
	c.x = a.x - b.x;
	c.y = a.y - b.y;
	c.z = a.z - b.z;
	return(c);
}
float3 sub(const float3& a, const real b) {
	float3 c;
	c.x = a.x - b;
	c.y = a.y - b;
	c.z = a.z - b;
	return(c);
}
float3 mul(const float3& a, const float3& b) {
	float3 c;
	c.x = a.x * b.x;
	c.y = a.y * b.y;
	c.z = a.z * b.z;
	return(c);
}
float3 div(const float3& a, const float3& b) {
	float3 c;
	c.x = a.x / b.x;
	c.y = a.y / b.y;
	c.z = a.z / b.z;
	return(c);
}
float3 div(const float3& a, const real b) {
	float3 c;
	c.x = a.x / b;
	c.y = a.y / b;
	c.z = a.z / b;
	return(c);
}

float3 mul(const float3& a, const real b) {
	float3 c;
	c.x = a.x * b;
	c.y = a.y * b;
	c.z = a.z * b;
	return(c);
}
float3 mul(const real a, const float3& b) {
	float3 c;
	c.x = a * b.x;
	c.y = a * b.y;
	c.z = a * b.z;
	return(c);
}

float2 mul(const float2x2& m, const float2 v) {
	float2 r;
	r.x = m.m00 * v.x + m.m01 * v.y;
	r.y = m.m10 * v.x + m.m11 * v.y;
	return(r);
}

float3 abs(const float3& a) {
	float3 r;
	r.x = fabsf(a.x);
	r.y = fabsf(a.y);
	r.z = fabsf(a.z);
	return(r);
}
float3 min(const float3& a, const float3& b) {
	float3 r;
	r.x = fminf(a.x, b.x);
	r.y = fminf(a.y, b.y);
	r.z = fminf(a.z, b.z);
	return(r);
}
float3 max(const float3& a, const float3& b) {
	float3 r;
	r.x = fmaxf(a.x, b.x);
	r.y = fmaxf(a.y, b.y);
	r.z = fmaxf(a.z, b.z);
	return(r);
}

float2x2 invert(const float2x2& m) {
	float2x2 i;
	real c = 1.0f / (m.m00 * m.m11 - m.m01 * m.m10);
	i.m00 = m.m11 * c;
	i.m01 = -m.m01 * c;
	i.m10 = -m.m10 * c;
	i.m11 = m.m00 * c;
	return(i);
}

float3 negate(const float3& a) {
	float3 c;
	c.x = -a.x;
	c.y = -a.y;
	c.z = -a.z;
	return(c);
}

float3 cross(const float3& a, const float3& b) {
	float3 c;
	c.x = a.y * b.z - a.z * b.y;
	c.y = a.z * b.x - a.x * b.z;
	c.z = a.x * b.y - a.y * b.x;
	return(c);
}
real dot(const float3& a, const float3& b) {
	real d = a.x * b.x + a.y * b.y + a.z * b.z;
	return(d);
}
real squared_length(const float3& a) {
	return(dot(a, a));
}
real length(const float3& a) {
	return(sqrtf(squared_length(a)));
}

real squared_distance(const float3& a, const float3& b) {
	return(squared_length(sub(b, a)));
}
real distance(const float3& a, const float3& b) {
	return(length(sub(b, a)));
}

float3 normalize(const float3& a) {
	real l = length(a);
	return(float3(a.x / l, a.y / l, a.z / l));
}

float3 spherical2cartesian(real r, real theta, real phi) {
	float3 v(r * sinf(theta) * cosf(phi), r * sinf(theta) * sinf(phi), r * cosf(theta));
	return(v);
}
float3 spherical2cartesian(const float3& s) {
	return(spherical2cartesian(s.x, s.y, s.z)); // (s.x, s.y, s.z) <-> (r (radius), theta (inclination), phi (azimuth))
}
float3 cartesian2spherical(const float3& v) {
	real r = length(v);
	float3 s(r, acosf(v.z / r), atan2f(v.y, v.x)); // (s.x, s.y, s.z) <-> (r (radius), theta (inclination), phi (azimuth))
	if (s.z < 0.0f) s.z += (real)(M_PI + M_PI);
	return(s);
}

real sign(real v) {
	return((v < 0.0f) ? -1.0f : 1.0f);
}

struct Ray {
	float3 origin;
	float3 direction;
	Ray() {}
	Ray(const float3& origin, const float3& direction) : origin(origin), direction(direction) { }
	Ray(const float3& origin, const real theta, const real phi) : origin(origin) {
		direction = spherical2cartesian(1.0f, theta, phi);
	}
};

struct Superellipsoid {
	float3 origin;
	float3 radius;
	float3 exponent;
	float3x3 orientation;
	real refractive_index;
	real fuzziness_factor;

	Superellipsoid() : refractive_index(1.0f), fuzziness_factor(0.0f) {}

	Superellipsoid(const float3& origin, const float3& radius, const float3& exponent) : origin(origin),
		radius(radius),
		exponent(exponent),
		refractive_index(1.0f),
		fuzziness_factor(0.0f)
	{}

	Superellipsoid(const float3& origin, const float3& radius, const float3& exponent, const real refractive_index) : origin(origin),
		radius(radius),
		exponent(exponent),
		refractive_index(refractive_index),
		fuzziness_factor(0.0f)
	{}

	Superellipsoid(const float3& origin, const float3& radius, const float3& exponent, const real refractive_index, const real fuzziness_factor) : origin(origin),
		radius(radius),
		exponent(exponent),
		refractive_index(refractive_index),
		fuzziness_factor(fuzziness_factor)
	{}

	real squared_radius(real theta, real phi) const {
		real ct = cosf(theta);
		real st = sinf(theta);
		real cp = cosf(phi);
		real sp = sinf(phi);

		real ct_n1 = sign(ct) * powf(fabsf(ct), exponent.x); // .x == n1 == t
		real st_n1 = sign(st) * powf(fabsf(st), exponent.x); // .x == n1 == t
		real cp_n2 = sign(cp) * powf(fabsf(cp), exponent.y); // .y == n2 == r
		real sp_n2 = sign(sp) * powf(fabsf(sp), exponent.y); // .y == n2 == r

		float3 surf_p;
		surf_p.x = radius.x * st_n1 * cp_n2;
		surf_p.y = radius.y * st_n1 * sp_n2;
		surf_p.z = radius.z * ct_n1;

		real surf_r2 = squared_length(surf_p);
		return(surf_r2);
	}

	float3 normal(real theta, real phi) const {
		real ct = cosf(theta);
		real st = sinf(theta);
		real cp = cosf(phi);
		real sp = sinf(phi);

		real ct_2 = ct * ct;
		real st_2 = st * st;
		real cp_2 = cp * cp;
		real sp_2 = sp * sp;

		real ct_w1 = sign(ct) * powf(fabsf(ct), exponent.x); // .x == n1 == t
		real st_w1 = sign(st) * powf(fabsf(st), exponent.x); // .x == n1 == t
		real cp_w2 = sign(cp) * powf(fabsf(cp), exponent.y); // .y == n2 == r
		real sp_w2 = sign(sp) * powf(fabsf(sp), exponent.y); // .y == n2 == r

		float3 surf_p;
		surf_p.x = radius.x * st_w1 * cp_w2;
		surf_p.y = radius.y * st_w1 * sp_w2;
		surf_p.z = radius.z * ct_w1;
		if (fabsf(surf_p.x) < FLT_EPSILON) surf_p.x = sign(surf_p.x) * FLT_EPSILON;
		if (fabsf(surf_p.y) < FLT_EPSILON) surf_p.y = sign(surf_p.y) * FLT_EPSILON;
		if (fabsf(surf_p.z) < FLT_EPSILON) surf_p.z = sign(surf_p.z) * FLT_EPSILON;

		float3 surf_n;
		surf_n.x = st_2 * cp_2;
		surf_n.y = st_2 * sp_2;
		surf_n.z = ct_2;
		return(div(surf_n, surf_p));
	}

	real squared_radius_and_normal(real theta, real phi, float3& normal) const {
		real ct = cosf(theta);
		real st = sinf(theta);
		real cp = cosf(phi);
		real sp = sinf(phi);

		real ct_2 = ct * ct;
		real st_2 = st * st;
		real cp_2 = cp * cp;
		real sp_2 = sp * sp;

		real ct_w1 = sign(ct) * powf(fabsf(ct), exponent.x); // .x == n1 == t
		real st_w1 = sign(st) * powf(fabsf(st), exponent.x); // .x == n1 == t
		real cp_w2 = sign(cp) * powf(fabsf(cp), exponent.y); // .y == n2 == r
		real sp_w2 = sign(sp) * powf(fabsf(sp), exponent.y); // .y == n2 == r

		float3 surf_p;
		surf_p.x = radius.x * st_w1 * cp_w2;
		surf_p.y = radius.y * st_w1 * sp_w2;
		surf_p.z = radius.z * ct_w1;

		float3 surf_n;
		surf_n.x = st_2 * cp_2;
		surf_n.y = st_2 * sp_2;
		surf_n.z = ct_2;
		normal = mul(-1.0f, div(surf_n, surf_p));

		real surf_r2 = squared_length(surf_p);
		return(surf_r2);
	}

	real implicit_form(const float3& p) const {
		float3 r2 = mul(radius, radius);
		float3 rp = sub(p, origin);
		float3 p2 = mul(rp, rp);
		float3 s = div(p2, r2);

		float3 D;
		D.x = powf(s.x, 1.0f / exponent.y); // 1 / r
		D.y = powf(s.y, 1.0f / exponent.y); // 1 / r
		D.z = powf(s.z, 1.0f / exponent.x); // 1 / t

		real ret = powf(D.x + D.y, exponent.y / exponent.x) + D.z;
		return(ret);
	}

	real implicit_form(const float3& p, float3& dFdR) const {
		float3 r2 = mul(radius, radius);
		float3 rp = sub(p, origin);
		if (fabsf(rp.x) < 1.0e-05f) rp.x = sign(rp.x) * 1.0e-05f;
		if (fabsf(rp.y) < 1.0e-05f) rp.y = sign(rp.y) * 1.0e-05f;
		if (fabsf(rp.z) < 1.0e-05f) rp.z = sign(rp.z) * 1.0e-05f;

		float3 p2 = mul(rp, rp);
		float3 s = div(p2, r2);

		float3 D;
		D.x = powf(s.x, 1.0f / exponent.y); // 1 / r
		D.y = powf(s.y, 1.0f / exponent.y); // 1 / r
		D.z = powf(s.z, 1.0f / exponent.x); // 1 / t

		float3 c = mul(2.0f / exponent.x, div(D, rp));
		real W = powf(D.x + D.y, exponent.y / exponent.x - 1.0f);
		dFdR.x = c.x * W;
		dFdR.y = c.y * W;
		dFdR.z = c.z;

		real ret = powf(D.x + D.y, exponent.y / exponent.x) + D.z;
		return(ret);
	}

	bool intersect(Ray ray, real tolerance, float3& local_p, float3& local_n) const
	{
		// OBB -> AABB
		float3 vmin = mul(-1.0f, radius);
		float3 vmax = radius;

		// Ray vs OBB -> Ray vs AABB
		//float3x3 invm = transpose(orientation);
		//float3 pos = invm * (ray.origin - origin);
		//float3 dir = invm * ray.direction;
		float3 pos = sub(ray.origin, origin);
		const float3& dir = ray.direction;

		// Hit points with AABB
		float3 isign;
		isign.x = (dir.x < 0.0f) ? -1.0f : 1.0f;
		isign.y = (dir.y < 0.0f) ? -1.0f : 1.0f;
		isign.z = (dir.z < 0.0f) ? -1.0f : 1.0f;

		float3 idir;
		idir.x = (fabsf(dir.x) > FLT_EPSILON) ? 1.0f / dir.x : isign.x / FLT_EPSILON;
		idir.y = (fabsf(dir.y) > FLT_EPSILON) ? 1.0f / dir.y : isign.y / FLT_EPSILON;
		idir.z = (fabsf(dir.z) > FLT_EPSILON) ? 1.0f / dir.z : isign.z / FLT_EPSILON;

		float3 v1 = mul(sub(vmin, pos), idir);
		float3 v2 = mul(sub(vmax, pos), idir);
		float3 n = min(v1, v2);
		float3 f = max(v1, v2);

		real tn = fmaxf(n.x, fmaxf(n.y, n.z));
		real tf = fminf(f.x, fminf(f.y, f.z));
		if (tf < 0.0 || tn > tf) {
			return(false);
		}

		// Iterative proceduare of finding intersection point with superellipsoid
		real dt = (tf - tn) / 128.0f;
		real t0 = -2.0f * dt + ((tn < 0.0f) ? tf : tn);
		real t1 = -1.0f * dt + ((tn < 0.0f) ? tf : tn);

		// secant method of root refinement
		real S0 = implicit_form(add(pos, mul(t0, dir))) - 1.0f;
		real S1 = implicit_form(add(pos, mul(t1, dir))) - 1.0f;

		bool success = false;
		for (int i = 0; i < ITERS_MAX; i++)
		{
			real t = t0 - S0 * (t1 - t0) / (S1 - S0);
			float3 ip = add(pos, mul(t, dir));

			t0 = t1;
			t1 = t;

			S0 = S1;
			S1 = implicit_form(ip) - 1.0f;

			real t_error = fabsf(t1 - t0) / fmaxf(10.0f * tolerance, fmaxf(t0, t1));
			real s_error = S1 * S1;
			if (t_error < tolerance && s_error < tolerance)
			{
				float3 sip = cartesian2spherical(ip);
				local_p = ip;
				local_n = normal(sip.y, sip.z);
				success = true;
				break;
			}
		}

		return(success);
	}

	bool intersect(const float3& ray_ori, const float3& ray_dir, const real tolerance) const {
		// OBB -> AABB
		float3 vmin = mul(-1.0f, radius);
		float3 vmax = radius;

		// Ray vs OBB -> Ray vs AABB
		//float3x3 invm = transpose(orientation);
		//float3 pos = invm * (ray.origin - origin);
		//float3 dir = invm * ray.direction;
		float3 pos = sub(ray_ori, origin);
		float3 dir = ray_dir;

		// Hit points with AABB
		float3 isign;
		isign.x = (dir.x < 0.0f) ? -1.0f : 1.0f;
		isign.y = (dir.y < 0.0f) ? -1.0f : 1.0f;
		isign.z = (dir.z < 0.0f) ? -1.0f : 1.0f;

		float3 idir;
		idir.x = (fabsf(dir.x) > FLT_EPSILON) ? 1.0f / dir.x : isign.x / FLT_EPSILON;
		idir.y = (fabsf(dir.y) > FLT_EPSILON) ? 1.0f / dir.y : isign.y / FLT_EPSILON;
		idir.z = (fabsf(dir.z) > FLT_EPSILON) ? 1.0f / dir.z : isign.z / FLT_EPSILON;

		float3 v1 = mul(sub(vmin, pos), idir);
		float3 v2 = mul(sub(vmax, pos), idir);
		float3 n = min(v1, v2);
		float3 f = max(v1, v2);

		real tn = fmaxf(n.x, fmaxf(n.y, n.z));
		real tf = fminf(f.x, fminf(f.y, f.z));
		if (tf < 0.0 || tn > tf) {
			return(false);
		}

		// Iterative proceduare of finding intersection point with superellipsoid
		real dt = (tf - tn) / 128.0f;
		real t0 = -2.0f * dt + ((tn < 0.0f) ? tf : tn);
		real t1 = -1.0f * dt + ((tn < 0.0f) ? tf : tn);

		// secant method of root refinement
		real S0 = implicit_form(add(pos, mul(t0, dir))) - 1.0f;
		real S1 = implicit_form(add(pos, mul(t1, dir))) - 1.0f;

		bool success = false;
		for (int i = 0; i < ITERS_MAX; i++)
		{
			real t = t0 - S0 * (t1 - t0) / (S1 - S0);

			t0 = t1;
			t1 = t;

			S0 = S1;
			S1 = implicit_form(add(pos, mul(t1, dir))) - 1.0f;

			real t_error = fabsf(t1 - t0) / fmaxf(10.0f * tolerance, fmaxf(t0, t1));
			real s_error = S1 * S1;
			if (t_error < tolerance && s_error < tolerance)
			{
				success = true;
				break;
			}
		}

		return(success);
	}

	bool intersect(const Ray& ray, const real tolerance) const {
		return(intersect(ray.origin, ray.direction, tolerance));
	}

	void draw(const float2& canvas_min, const float2& canvas_max) {
		const int num_points = 64;

		int xmin = 0;
		int ymin = 0;
		int xmax = getmaxx();
		int ymax = getmaxy();

		float3 spherical(0.0f, 0.0f, 0.0f);
		spherical.x = sqrt(squared_radius(spherical.y, spherical.z));

		float3 cartesian0 = spherical2cartesian(spherical);
		int x0 = xmin + (xmax - xmin) * (cartesian0.x - canvas_min.x) / (canvas_max.x - canvas_min.x);
		int y0 = ymin + (ymax - ymin) * (cartesian0.z - canvas_min.y) / (canvas_max.y - canvas_min.y);
		for (int i = 0; i < num_points; i++) {
			spherical.y = M_PI * i / (num_points - 1);
			spherical.x = sqrt(squared_radius(spherical.y, spherical.z));

			float3 cartesian1 = spherical2cartesian(spherical);
			int x1 = xmin + (xmax - xmin) * (cartesian1.x - canvas_min.x) / (canvas_max.x - canvas_min.x);
			int y1 = ymin + (ymax - ymin) * (cartesian1.z - canvas_min.y) / (canvas_max.y - canvas_min.y);

			line(x0, y0, x1, y1);
			x0 = x1; y0 = y1;
		}

		spherical.y = 0;
		spherical.z = M_PI;
		spherical.x = sqrt(squared_radius(spherical.y, spherical.z));

		cartesian0 = spherical2cartesian(spherical);
		x0 = xmin + (xmax - xmin) * (cartesian0.x - canvas_min.x) / (canvas_max.x - canvas_min.x);
		y0 = ymin + (ymax - ymin) * (cartesian0.z - canvas_min.y) / (canvas_max.y - canvas_min.y);
		for (int i = 0; i < num_points; i++) {
			spherical.y = M_PI * i / (num_points - 1);
			spherical.x = sqrt(squared_radius(spherical.y, spherical.z));

			float3 cartesian1 = spherical2cartesian(spherical);
			int x1 = xmin + (xmax - xmin) * (cartesian1.x - canvas_min.x) / (canvas_max.x - canvas_min.x);
			int y1 = ymin + (ymax - ymin) * (cartesian1.z - canvas_min.y) / (canvas_max.y - canvas_min.y);

			line(x0, y0, x1, y1);
			x0 = x1; y0 = y1;
		}
	}
};

struct Medium {
	Medium() : refractive_index(1.0f) {}
	Medium(float rf) : refractive_index(rf) {}
	real refractive_index;
};

//-
// http://www.starkeffects.com/snells-law-vector.shtml
float3 snell_c(const float3& s, const float3& n, const real n1, const real n2) {
	real r1 = n1 / n2;
	real r2 = r1 * r1;
	float3 v1 = mul(r1, cross(n, cross(negate(n), s)));
	float3 v2 = mul(n, sqrtf(1.0f - r2 * dot(cross(n, s), cross(n, s))));
	float3 r = sub(v1, v2);
	return(r);
}

// http://www.cse.chalmers.se/edu/year/2013/course/TDA361/refractionvector.pdf
// https://physics.stackexchange.com/questions/435512/snells-law-in-vector-form
float3 snell_d(const float3& s, const float3& n, const real n1, const real n2) {
	real r1 = n1 / n2;
	real r2 = r1 * r1;
	real d = dot(n, s);
	float3 v1 = mul(sub(s, mul(d, n)), r1);
	float3 v2 = mul(sqrtf(1.0f - r2 * (1.0f - d * d)), n);
	float3 r = sub(v1, v2);
	return(r);
}

float smooth_step(float x) {
	if (x < 0.0f) return(0.0f);
	if (x > 1.0f) return(1.0f);
	return(6.0f * powf(x, 5.0f) - 15.0f * powf(x, 4.0f) + 10.0f * powf(x, 3.0f));
}
float smooth_step_derivative(float x) {
	if (x < 0.0f) return(0.0f);
	if (x > 1.0f) return(0.0f);
	return(30.0f * powf(x, 4.0f) - 60.0f * powf(x, 3.0f) + 30.0f * powf(x, 2.0f));
}

void medium_refractive_index(const Medium& md, const Superellipsoid& se, const float3& pos, float4& grad_rf) {
	float3 o = sub(pos, se.origin);

	float3 dFdR;
	real sl = se.implicit_form(pos, dFdR);

	const float alpha = 6.0f;
	const float beta = 5.0f;
	float F = expf(-alpha * powf(sl, beta));
	float C = -alpha * beta * F * powf(sl, beta - 1.0f);
	dFdR.x *= C;
	dFdR.y *= C;
	dFdR.z *= C;

	//const float beta = 2.0f;
	//float SS = smooth_step(sl);
	//float F = 1.0f - powf(SS, beta);
	//float C = -beta * powf(SS, beta - 1.0f) * smooth_step_derivative(sl);
	//dFdR.x *= C;
	//dFdR.y *= C;
	//dFdR.z *= C;

	float dn = se.refractive_index - md.refractive_index;
	grad_rf.x = dn * dFdR.x;
	grad_rf.y = dn * dFdR.y;
	grad_rf.z = dn * dFdR.z;
	grad_rf.w = md.refractive_index + dn * F;
}

// https://ru.wikibooks.org/wiki/%D0%A0%D0%B5%D0%B0%D0%BB%D0%B8%D0%B7%D0%B0%D1%86%D0%B8%D0%B8_%D0%B0%D0%BB%D0%B3%D0%BE%D1%80%D0%B8%D1%82%D0%BC%D0%BE%D0%B2/%D0%9C%D0%B5%D1%82%D0%BE%D0%B4_%D0%BF%D1%80%D0%BE%D0%B3%D0%BE%D0%BD%D0%BA%D0%B8
//n - число уравнений (строк матрицы)
//b - диагональ, лежащая под главной (нумеруется: [1;n-1])
//c - главная диагональ матрицы A (нумеруется: [0;n-1])
//d - диагональ, лежащая над главной (нумеруется: [0;n-2])
//f - правая часть (столбец)
//x - решение, массив x будет содержать ответ
// Данный код работает при предположении, что b[0] = 0, d[n-1] = 0.
void solveMatrix(int n, float4* a, float3* b, float3* c, float3* d, float3* x)
{
	float3 m;
	for (int i = 1; i < n; i++) {
		m.x = b[i].x / c[i - 1].x;
		m.y = b[i].y / c[i - 1].y;
		m.z = b[i].z / c[i - 1].z;

		c[i].x = c[i].x - m.x * d[i - 1].x;
		c[i].y = c[i].y - m.y * d[i - 1].y;
		c[i].z = c[i].z - m.z * d[i - 1].z;

		a[i].x = a[i].x - (m.x * a[i - 1].x);
		a[i].y = a[i].y - (m.y * a[i - 1].y);
		a[i].z = a[i].z - (m.z * a[i - 1].z);
	}

	x[n - 1].x = a[n - 1].x / c[n - 1].x;
	x[n - 1].y = a[n - 1].y / c[n - 1].y;
	x[n - 1].z = a[n - 1].z / c[n - 1].z;
	for (int i = n - 2; i >= 0; i--) {
		x[i].x = (a[i].x - (d[i].x * x[i + 1].x)) / c[i].x;
		x[i].y = (a[i].y - (d[i].y * x[i + 1].y)) / c[i].y;
		x[i].z = (a[i].z - (d[i].z * x[i + 1].z)) / c[i].z;
	}
}
//void solveMatrixYZ(int n, float3* b, float3* c, float3* d, float3* r, float3* x)
//{
//    float3 m;
//    for(int i = 1; i < n; i++) {
//        m.y = b[i].y / c[i - 1].y;
//        m.z = b[i].z / c[i - 1].z;
//
//        c[i].y = c[i].y - (m.y * d[i - 1].y);
//        c[i].z = c[i].z - (m.z * d[i - 1].z);
//
//        r[i].y = r[i].y - (m.y * r[i - 1].y);
//        r[i].z = r[i].z - (m.z * r[i - 1].z);
//    }
//
//    x[n - 1].y = r[n - 1].y / c[n - 1].y;
//    x[n - 1].z = r[n - 1].z / c[n - 1].z;
//    for(int i = n - 2; i >= 0; i--) {
//        x[i].y = (r[i].y - (d[i].y * x[i + 1].y)) / c[i].y;
//        x[i].z = (r[i].z - (d[i].z * x[i + 1].z)) / c[i].z;
//    }
//}

void draw_ray(const float3 p[], int length, const float2& bbmin, const float2& bbmax, const int line_color, const int point_color) {
	int xmin = 0;
	int ymin = 0;
	int xmax = getmaxx();
	int ymax = getmaxy();

	float3 pb = p[0];
	int xb = xmin + (xmax - xmin) * (pb.x - bbmin.x) / (bbmax.x - bbmin.x);
	int yb = ymin + (ymax - ymin) * (pb.z - bbmin.y) / (bbmax.y - bbmin.y);

	setcolor(point_color);
	circle(xb, ymax - yb, 1);

	for (int j = 1; j < length; j++) {
		float3 pe = p[j];
		int xe = xmin + (xmax - xmin) * (pe.x - bbmin.x) / (bbmax.x - bbmin.x);
		int ye = ymin + (ymax - ymin) * (pe.z - bbmin.y) / (bbmax.y - bbmin.y);

		setcolor(line_color);
		line(xb, ymax - yb, xe, ymax - ye);
		setcolor(point_color);
		circle(xe, ymax - ye, 1);
		setcolor(WHITE);

		xb = xe; yb = ye;
	}
}

void draw_ray(const float3& b, const float3& e, const float2& bbmin, const float2& bbmax, const int line_color, const int point_color) {
	int xmin = 0;
	int ymin = 0;
	int xmax = getmaxx();
	int ymax = getmaxy();

	const float3& pb = b;
	int xb = xmin + (xmax - xmin) * (pb.x - bbmin.x) / (bbmax.x - bbmin.x);
	int yb = ymin + (ymax - ymin) * (pb.z - bbmin.y) / (bbmax.y - bbmin.y);

	const float3& pe = e;
	int xe = xmin + (xmax - xmin) * (pe.x - bbmin.x) / (bbmax.x - bbmin.x);
	int ye = ymin + (ymax - ymin) * (pe.z - bbmin.y) / (bbmax.y - bbmin.y);

	setcolor(point_color);
	circle(xb, ymax - yb, 1);

	setcolor(line_color);
	line(xb, ymax - yb, xe, ymax - ye);

	setcolor(point_color);
	circle(xe, ymax - ye, 1);

	setcolor(WHITE);
}

bool calc_ray_path(const float3& src,
	const float3& dst,
	const Medium& md,
	const Superellipsoid& se,
	const float dt2dl,
	const float tolerance,
	const int iters_max,
	const int points_num,
	float4 a[],
	float3 b[],
	float3 c[],
	float3 d[],
	float3 e[],
	float3 f[],
	float3& ip,
	float3& op,
	float3& in,
	float3& on,
	int& iters) {
	float3 src2dst = sub(dst, src);
	float L0 = length(src2dst);
	float3 ray_dir = div(src2dst, L0);

	if (!se.intersect(src, ray_dir, tolerance)) {
		return(false);
	}
	float T0 = L0 * L0;
	float dl = 1.0f / (points_num - 1);
	float dt = dt2dl * dl;

	float c0 = 1.0f / (2.0f * dt);
	float c1 = dt * L0;

	// first approximation (normalized space)
	for (int i = 0; i < points_num; i++) {
		float t = i * dl;
		float3 p = div(add(src, mul(t, src2dst)), L0);
		e[i] = p;
		f[i] = p;
	}

	int iters_num = 0;
	float error = 0.0f;
	do {
		a[0].x = f[0].x;
		a[0].y = f[0].y;
		a[0].z = f[0].z;
		a[0].w = md.refractive_index;
		for (int i = 1; i < points_num - 1; i++) {
			medium_refractive_index(md, se, mul(L0, f[i]), a[i]);

			float c2 = c0 * distance(f[i - 1], f[i + 1]);
			a[i].x = c2 * (e[i].x - c1 * a[i].x);
			a[i].y = c2 * (e[i].y - c1 * a[i].y);
			a[i].z = c2 * (e[i].z - c1 * a[i].z);
		}
		a[points_num - 1].x = f[points_num - 1].x;
		a[points_num - 1].y = f[points_num - 1].y;
		a[points_num - 1].z = f[points_num - 1].z;
		a[points_num - 1].w = md.refractive_index;

		// fill diagonals
		b[0].x = b[0].y = b[0].z = 0.0f;
		c[0].x = c[0].y = c[0].z = 1.0f;
		d[0].x = d[0].y = d[0].z = 0.0f;
		for (int i = 1; i < points_num - 1; i++) {
			float dl0 = distance(f[i - 1], f[i + 1]);
			float dl1 = distance(f[i - 1], f[i]);
			float dl2 = distance(f[i], f[i + 1]);

			float rf1 = (a[i - 1].w + a[i].w) / 2.0f;
			float rf2 = (a[i].w + a[i + 1].w) / 2.0f;

			real v0 = -rf1 / dl1;
			real v1 = (rf1 / dl1 + rf2 / dl2 + c0 * dl0);
			real v2 = -rf2 / dl2;

			b[i].x = b[i].y = b[i].z = v0;
			c[i].x = c[i].y = c[i].z = v1;
			d[i].x = d[i].y = d[i].z = v2;
		}
		b[points_num - 1].x = b[points_num - 1].y = b[points_num - 1].z = 0.0f;
		c[points_num - 1].x = c[points_num - 1].y = c[points_num - 1].z = 1.0f;
		d[points_num - 1].x = d[points_num - 1].y = d[points_num - 1].z = 0.0f;

		// tridiagonal solver
		solveMatrix(points_num, a, b, c, d, f);

		// error estimator
		error = 0.0f;
		for (int i = 1; i < points_num - 1; i++) {
			real fm0 = length(e[i]);
			real fm1 = length(f[i]);
			real dfm = (fm1 - fm0) / fmaxf(tolerance, fmaxf(fm0, fm1));
			error += dfm * dfm;

			e[i] = f[i];
		}
		error = sqrtf(error / (points_num - 3));
		iters_num++;
    } while (error > tolerance && iters_num < iters_max);

	// restore the ray path in world space
	int ray_points = 1 + (points_num / 2) / 10;

	Ray ir;
	Ray or ;
	ir.origin = mul(f[0], L0);
	or .origin = mul(f[points_num - 1], L0);

	float3 ip0 = ir.origin;
	float3 op0 = or .origin;
	for (int i = 1; i < ray_points; i++) {
		float3 ip1 = mul(f[i], L0);
		float3 op1 = mul(f[(points_num - 1) - i], L0);
		ir.direction = add(ir.direction, sub(ip1, ip0));
		or .direction = add(or .direction, sub(op1, op0));
		ip0 = ip1;
		op0 = op1;
	}
	ir.direction = normalize(div(ir.direction, ray_points - 1));
	or .direction = normalize(div(or .direction, ray_points - 1));

	bool is_intersect = error <= tolerance;
	is_intersect &= se.intersect(ir, tolerance, ip, in);
	is_intersect &= se.intersect(or , tolerance, op, on);

	for (int i = 0; i < points_num; i++) {
		f[i].x *= L0;
		f[i].y *= L0;
		f[i].z *= L0;
	}

	iters = iters_num;
	return(is_intersect);
}

bool calc_ray_path2(const float3& src,
	const float3& dst,
	const Medium& md,
	const Superellipsoid& se,
	const float dt2dl,
	const float tolerance,
	const int iters_max,
	const int points_num,
	float4 a[],
	float3 b[],
	float3 c[],
	float3 d[],
	float3 e[],
	float3 f[],
	float3 g[],
	float3& ip,
	float3& op,
	float3& in,
	float3& on,
	int& iters) {
	float3 src2dst = sub(dst, src);
	float L0 = length(src2dst);
	float3 ray_dir = div(src2dst, L0);

	if (!se.intersect(src, ray_dir, tolerance)) {
		return(false);
	}
	float T0 = L0 * L0;
	float dl = 1.0f / (points_num - 1);
	float dt = dt2dl * dl;

	float c0 = 1.0f / dt;
	float c1 = dt * L0 / 2.0f;

	// first approximation (normalized space)
	for (int i = 0; i < points_num; i++) {
		float t = i * dl;
		float3 p = div(add(src, mul(t, src2dst)), L0);
		e[i] = p;
		f[i] = p;
		g[i] = p;
	}

	int iters_num = 0;
	float error = 0.0f;
	do {
		a[0].x = g[0].x;
		a[0].y = g[0].y;
		a[0].z = g[0].z;
		a[0].w = md.refractive_index;
		for (int i = 1; i < points_num - 1; i++) {
			medium_refractive_index(md, se, mul(L0, g[i]), a[i]);

			float c2 = c0 * distance(g[i - 1], g[i + 1]);
			a[i].x = c2 * (f[i].x - e[i].x / 4.0f - c1 * a[i].x);
			a[i].y = c2 * (f[i].y - e[i].y / 4.0f - c1 * a[i].y);
			a[i].z = c2 * (f[i].z - e[i].z / 4.0f - c1 * a[i].z);
		}
		a[points_num - 1].x = g[points_num - 1].x;
		a[points_num - 1].y = g[points_num - 1].y;
		a[points_num - 1].z = g[points_num - 1].z;
		a[points_num - 1].w = md.refractive_index;

		// fill diagonals
		b[0].x = b[0].y = b[0].z = 0.0f;
		c[0].x = c[0].y = c[0].z = 1.0f;
		d[0].x = d[0].y = d[0].z = 0.0f;
		for (int i = 1; i < points_num - 1; i++) {
			float dl0 = distance(g[i - 1], g[i + 1]);
			float dl1 = distance(g[i - 1], g[i]);
			float dl2 = distance(g[i], g[i + 1]);

			float rf1 = (a[i - 1].w + a[i].w) / 2.0f;
			float rf2 = (a[i].w + a[i + 1].w) / 2.0f;

			real v0 = -rf1 / dl1;
			real v1 = (rf1 / dl1 + rf2 / dl2 + (3.0f / 4.0f) * c0 * dl0);
			real v2 = -rf2 / dl2;

			b[i].x = b[i].y = b[i].z = v0;
			c[i].x = c[i].y = c[i].z = v1;
			d[i].x = d[i].y = d[i].z = v2;
		}
		b[points_num - 1].x = b[points_num - 1].y = b[points_num - 1].z = 0.0f;
		c[points_num - 1].x = c[points_num - 1].y = c[points_num - 1].z = 1.0f;
		d[points_num - 1].x = d[points_num - 1].y = d[points_num - 1].z = 0.0f;

		// tridiagonal solver
		solveMatrix(points_num, a, b, c, d, g);

		// error estimator
		error = 0.0f;
		for (int i = 1; i < points_num - 1; i++) {
			real fm0 = length(f[i]);
			real fm1 = length(g[i]);
			real dfm = (fm1 - fm0) / fmaxf(tolerance, fmaxf(fm0, fm1));
			error += dfm * dfm;

			e[i] = f[i];
			f[i] = g[i];
		}
		error = sqrtf(error / (points_num - 3));
		iters_num++;
	} while (error > tolerance && iters_num < iters_max);

	// restore the ray path in world space
	int ray_points = 1 + (points_num / 2) / 10;

	Ray ir;
	Ray or ;
	ir.origin = mul(f[0], L0);
	or .origin = mul(f[points_num - 1], L0);

	float3 ip0 = ir.origin;
	float3 op0 = or .origin;
	for (int i = 1; i < ray_points; i++) {
		float3 ip1 = mul(f[i], L0);
		float3 op1 = mul(f[(points_num - 1) - i], L0);
		ir.direction = add(ir.direction, sub(ip1, ip0));
		or .direction = add(or .direction, sub(op1, op0));
		ip0 = ip1;
		op0 = op1;
	}
	ir.direction = normalize(div(ir.direction, ray_points - 1));
	or .direction = normalize(div(or .direction, ray_points - 1));

	bool is_intersect = error <= tolerance;
	is_intersect &= se.intersect(ir, tolerance, ip, in);
	is_intersect &= se.intersect(or , tolerance, op, on);

	for (int i = 0; i < points_num; i++) {
		g[i].x *= L0;
		g[i].y *= L0;
		g[i].z *= L0;
	}

	iters = iters_num;
	return(is_intersect);
}

/*
const int N = 151;

float smooth_step(float x) {
	if(x < 0.0) return(0.0);
	if(x > 1.0) return(1.0);
	return(6.0 * pow(x, 5.0) - 15.0 * pow(x, 4.0) + 10.0 * pow(x, 3.0));
}
float smooth_step_derivative(float x) {
	if(x < 0.0) return(0.0);
	if(x > 1.0) return(0.0);
	return(30.0 * pow(x, 4.0) - 60.0 * pow(x, 3.0) + 30.0 * pow(x, 2.0));
}
void medium_refractive_index(in Medium md, in Superellipsoid se, in vec3 pos, inout vec4 grad_rf) {
	vec3 o = pos - se.origin;

	vec3 dFdR;
	float sl = se.implicit_form(pos, dFdR);

	const float alpha = 6.0;
	const float beta = 5.0;
	float F = exp(-alpha * pow(sl, beta));
	float C = -alpha * beta * F * pow(sl, beta - 1.0);
	dFdR.x *= C;
	dFdR.y *= C;
	dFdR.z *= C;

	//const float beta = 2.0;
	//float SS = smooth_step(sl);
	//float F = 1.0 - pow(SS, beta);
	//float C = -beta * pow(SS, beta - 1.0) * smooth_step_derivative(sl);
	//dFdR.x *= C;
	//dFdR.y *= C;
	//dFdR.z *= C;

	float dn = se.refractive_index - md.refractive_index;
	grad_rf.x = dn * dFdR.x;
	grad_rf.y = dn * dFdR.y;
	grad_rf.z = dn * dFdR.z;
	grad_rf.w = md.refractive_index + dn * F;
}

bool calc_ray_path_glsl(in vec3 src,
	in vec3 src,
	in Medium md,
	in Superellipsoid se,
	in float dt2dl,
	in float tolerance,
	in int iters_max,
	in int points_num,
	in vec4 a[N],
	in vec3 b[N],
	in vec3 c[N],
	in vec3 d[N],
	in vec3 e[N],
	in vec3 f[N],
	in vec3 g[N],
	inout vec3 ip,
	inout vec3 op,
	inout vec3 in,
	inout vec3 on)
{
	vec3 src2dst = dst - src;
	float L0 = length(src2dst);
	vec3 ray_dir = src2dst / L0;

	if(!se.intersect(src, ray_dir, tolerance)) {
		return(false);
	}
	float T0 = L0 * L0;
	float dl = 1.0 / (points_num - 1);
	float dt = dt2dl * dl;

	float c0 = 1.0 / dt;
	float c1 = dt * L0 / 2.0;

	// first approximation (normalized space)
	for(int i = 0; i < points_num; i++) {
		float t = i * dl;
		vec3 p = (src + (t * src2dst)) / L0;
		e[i] = p;
		f[i] = p;
		g[i] = p;
	}

	int iters_num = 0;
	float error = 0.0;
	do {
		a[0].x = g[0].x;
		a[0].y = g[0].y;
		a[0].z = g[0].z;
		a[0].w = md.refractive_index;
		for(int i = 1; i < points_num - 1; i++) {
			medium_refractive_index(md, se, L0 * g[i], a[i]);

			float c2 = c0 * distance(g[i - 1], g[i + 1]);
			a[i].x = c2 * (f[i].x - e[i].x / 4.0 - c1 * a[i].x);
			a[i].y = c2 * (f[i].y - e[i].y / 4.0 - c1 * a[i].y);
			a[i].z = c2 * (f[i].z - e[i].z / 4.0 - c1 * a[i].z);
		}
		a[points_num - 1].x = g[points_num - 1].x;
		a[points_num - 1].y = g[points_num - 1].y;
		a[points_num - 1].z = g[points_num - 1].z;
		a[points_num - 1].w = md.refractive_index;

		// fill diagonals
		b[0].x = b[0].y = b[0].z = 0.0;
		c[0].x = c[0].y = c[0].z = 1.0;
		d[0].x = d[0].y = d[0].z = 0.0;
		for(int i = 1; i < points_num - 1; i++) {
			float dl0 = distance(g[i - 1], g[i + 1]);
			float dl1 = distance(g[i - 1], g[i]);
			float dl2 = distance(g[i], g[i + 1]);

			float rf1 = (a[i - 1].w + a[i].w) / 2.0;
			float rf2 = (a[i].w + a[i + 1].w) / 2.0;

			real v0 = -rf1 / dl1;
			real v1 = (rf1 / dl1 + rf2 / dl2 + (3.0 / 4.0) * c0 * dl0);
			real v2 = -rf2 / dl2;

			b[i].x = b[i].y = b[i].z = v0;
			c[i].x = c[i].y = c[i].z = v1;
			d[i].x = d[i].y = d[i].z = v2;
		}
		b[points_num - 1].x = b[points_num - 1].y = b[points_num - 1].z = 0.0;
		c[points_num - 1].x = c[points_num - 1].y = c[points_num - 1].z = 1.0;
		d[points_num - 1].x = d[points_num - 1].y = d[points_num - 1].z = 0.0;

		// tridiagonal solver
		solveMatrix(points_num, a, b, c, d, g);

		// error estimator
		error = 0.0;
		for (int i = 1; i < points_num - 1; i++) {
			real fm0 = length(f[i]);
			real fm1 = length(g[i]);
			real dfm = (fm1 - fm0) / fmaxf(tolerance, fmaxf(fm0, fm1));
			error += dfm * dfm;

			e[i] = f[i];
			f[i] = g[i];
		}
		error = sqrt(error / (points_num - 3));
		iters_num++;
	} while (error > tolerance && iters_num < iters_max);

	// restore the ray path in world space
	int ray_points = 1 + (points_num / 2) / 10;

	Ray ir;
	Ray or ;
	ir.origin = f[0] * L0;
	or.origin = f[points_num - 1] * L0;

	vec3 ip0 = ir.origin;
	vec3 op0 = or.origin;
	for(int i = 1; i < ray_points; i++) {
		vec3 ip1 = f[i] * L0;
		vec3 op1 = f[(points_num - 1) - i] * L0;
		ir.direction = ir.direction + (ip1 - ip0);
		or.direction = or.direction + (op1 - op0);
		ip0 = ip1;
		op0 = op1;
	}
	ir.direction = normalize(div(ir.direction, ray_points - 1));
	or.direction = normalize(div(or.direction, ray_points - 1));

	bool is_intersect = error <= tolerance;
	is_intersect &= se.intersect(ir, tolerance, ip, in);
	is_intersect &= se.intersect(or, tolerance, op, on);

	return(is_intersect);
}
*/

void run() {
	float2 canvas_min(-6.0f, -6.0f);
	float2 canvas_max(+6.0f, +6.0f);

	const real n1 = 1.0f;
	const real n2 = 1.5f;

	const int num_apoints = 128;
	const int num_dpoints = 151;
	float3 src(-5.0f, 0.0f, 0.0f);
	float3 dst(0.0f, 0.0f, 0.0f);

	Medium md(n1);

	float3 se_o(0.0f, 0.0f, 0.0f);
	float3 se_r(1.0f, 1.0f, 1.0f);
	float3 se_n(1.0f, 1.0f, 1.0f);
	Superellipsoid se(se_o, se_r, se_n, n2, 0.15f);
	se.draw(canvas_min, canvas_max);

	float4 a[num_dpoints];
	float3 b[num_dpoints];
	float3 c[num_dpoints];
	float3 d[num_dpoints];

	float3 p0[num_dpoints];
	float3 p1[num_dpoints];
	float3 p2[num_dpoints];

	const real src_to_dst = 10.0f; // euclidean distance between light and target point
	real spl_visible_angle = 0.95f * atanf(se.radius.y / distance(src, se.origin)); // half visible angle of sphere

	real characteristic_length = src_to_dst / (num_dpoints - 1);
	real characteristic_angle = spl_visible_angle / (num_apoints - 1);

	float3 ip;
	float3 op;
	float3 in;
	float3 on;

	real ave_iters = 0.0f;
	for (int i = 0; i < num_apoints; i++) {
		real theta = (M_PI / 2.0f) + (2 * i * characteristic_angle - spl_visible_angle);
		real phi = 0.0f;
		dst = add(src, mul(src_to_dst, spherical2cartesian(1.0f, theta, phi)));

		int iters = 0;
		//bool ray_found = calc_ray_path(src, dst, md, se, 0.75f, 1.0e-05f, 1024, num_dpoints, a, b, c, d, p0, p2, ip, op, in, on, iters);
		bool ray_found = calc_ray_path2(src, dst, md, se, 0.5f, 1.0e-05f, 1024, num_dpoints, a, b, c, d, p0, p1, p2, ip, op, in, on, iters);
		ave_iters += iters;

		// draw ray
		if (ray_found) {
			//draw_ray(src, ip, canvas_min, canvas_max, GREEN, RED);
			//draw_ray(op, dst, canvas_min, canvas_max, GREEN, RED);
			draw_ray(p2, num_dpoints, canvas_min, canvas_max, GREEN, RED);
		}
		else {
			//draw_ray(src, ip, canvas_min, canvas_max, RED, RED);
			//draw_ray(op, dst, canvas_min, canvas_max, RED, RED);
			draw_ray(p2, num_dpoints, canvas_min, canvas_max, RED, RED);
		}
	}

	ave_iters /= num_apoints;
	ave_iters = ave_iters;
}
